package es.studium.Chat;

import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSocket;
import java.io.IOException;

public class SSLServer {
	public static void main(String[] argv) {
		System.setProperty("javax.net.ssl.keyStore", "C:\\Users\\luigi\\ServerKeyStore.jks");
		System.setProperty("javax.net.ssl.keyStorePassword", "Studium;");

		try {
			SSLServerSocketFactory sslFactory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
			SSLServerSocket srvSocket = (SSLServerSocket) sslFactory.createServerSocket(44444);

			System.out.println("Escuchando...");

			while (true) {
				SSLSocket cliSocket = (SSLSocket) srvSocket.accept();
				// Aqu� continua la l�gica del servidor para manejar las conexiones SSL
				// ...
			}
		} catch (IOException ex) {
			System.out.println("Error en las comunicaciones: " + ex);
		}
	}
}
