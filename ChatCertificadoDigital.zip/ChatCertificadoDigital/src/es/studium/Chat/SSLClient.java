package es.studium.Chat;

import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class SSLClient {
    public static void main(String[] args) {
        // Importa las clases adecuadas para SSL.
        System.setProperty("javax.net.ssl.trustStore", "C:\\Users\\luigi\\ClientTrustStore.jks");
        System.setProperty("javax.net.ssl.trustStorePassword", "Studium;");
        SSLSocket clienteSocket = null;
        try {
            // Crea un SSLSocket en lugar de un Socket.
            SSLSocketFactory sslFactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
            clienteSocket = (SSLSocket) sslFactory.createSocket("localhost", 44444);

            Scanner teclado = new Scanner(System.in);
            PrintStream writer = new PrintStream(clienteSocket.getOutputStream());

            System.out.println("Deja una l�nea en blanco para terminar:");

            String texto = teclado.nextLine();
            // Configura el flujo de entrada y salida para trabajar con SSL.
            while (!texto.equals("")) {
                writer.println(texto);
                writer.flush();
                texto = teclado.nextLine();
            }
            writer.println("<< FIN >>");
            writer.flush();

            // Cierra el socket cuando termina la comunicaci�n.
            clienteSocket.close();
            teclado.close();
        } catch (IOException ex) {
            System.out.println("Error en las comunicaciones: " + ex);
        }
    }
}
