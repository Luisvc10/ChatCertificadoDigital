package es.studium.Chat;
import javax.net.ssl.SSLSocket;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class HiloServidor extends Thread {
    DataInputStream fentrada;
    SSLSocket socket;
    boolean fin = false;

    public HiloServidor(SSLSocket socket) {
        this.socket = socket;
        try {
            fentrada = new DataInputStream(socket.getInputStream());
        } catch (IOException e) {
            System.out.println("Error de E/S");
            e.printStackTrace();
        }
    }

    public void run() {
        ServidorChat.mensaje.setText("N�mero de conexiones actuales: " + ServidorChat.ACTUALES);
        String texto = ServidorChat.textarea.getText();
        EnviarMensajes(texto);
        while (!fin) {
            String cadena = "";
            try {
                cadena = fentrada.readUTF();
                if (cadena.trim().equals("*")) {
                    ServidorChat.ACTUALES--;
                    ServidorChat.mensaje.setText("N�mero de conexiones actuales: " + ServidorChat.ACTUALES);
                    fin = true;
                } else {
                    ServidorChat.textarea.append(cadena + "\n");
                    texto = ServidorChat.textarea.getText();
                    EnviarMensajes(texto);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                fin = true;
            }
        }
    }

    private void EnviarMensajes(String texto) {
        for (int i = 0; i < ServidorChat.CONEXIONES; i++) {
            SSLSocket socket = ServidorChat.tabla[i];
            try {
                DataOutputStream fsalida = new DataOutputStream(socket.getOutputStream());
                fsalida.writeUTF(texto);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
